import root from './root';
import { combineReducers} from 'redux';


const reducers = combineReducers({
    root
});

export default reducers;